THRIFT W MEHAK — WEBSITE PREVIEW

Open index.html in Safari to preview. The Mystery Bundles section includes a ₹1,000 3-piece bundle, a ₹1,500 5-piece bundle, optional ₹200 customisation, a notes field, and an automatically updated estimated total.

Before publishing: replace sample product content and images, configure the WhatsApp number and Instagram URL in index.html. This is a static preview; it does not include real Razorpay payments, customer accounts, persistent orders, or an admin dashboard.
